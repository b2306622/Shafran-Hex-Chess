using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

/// <summary>
/// Offline tournament runner over the project's GameState/MoveGenerator.
/// It keeps the visual board untouched while replaying independent games in
/// cloned GameState objects, so large batches do not require piece animations.
///
/// Supported participants:
/// Minimax Alpha-Beta, PPO Base, PPO + Minimax Guidance D1/D2, and
/// AlphaZero dual-head ONNX + MCTS variants.
/// </summary>
public sealed class AITournamentManager : MonoBehaviour
{
    [Header("Participants")]
    [SerializeField]
    private bool enableMinimax = true;

    [SerializeField]
    private bool enablePpoBase = true;

    [SerializeField]
    private bool enablePpoD1 = true;

    [SerializeField]
    private bool enablePpoD2 = true;

    [SerializeField]
    private bool enableAlphaZeroBase = true;

    [SerializeField]
    private bool enableAlphaZeroD1 = true;

    [SerializeField]
    private bool enableAlphaZeroD2 = true;

    [Header("Final A / B / C Models") ]
    [Tooltip("When enabled, run only MODEL_A_PRIME / MODEL_B_PRIME / MODEL_C_PRIME." )]
    [SerializeField]
    private bool finalThreeOnly = false;

    [SerializeField]
    private bool enableModelAPrime = true;

    [SerializeField]
    private bool enableModelBPrime = true;

    [SerializeField]
    private bool enableModelCPrime = true;

    [Header("Evaluators")]
    [SerializeField]
    private SentisPpoPolicyEvaluator ppoBaseEvaluator;

    [SerializeField]
    private SentisPpoPolicyEvaluator ppoD1Evaluator;

    [SerializeField]
    private SentisPpoPolicyEvaluator ppoD2Evaluator;

    [SerializeField]
    private SentisDualHeadPolicyValueEvaluator alphaZeroBaseEvaluator;

    [SerializeField]
    private SentisDualHeadPolicyValueEvaluator alphaZeroD1Evaluator;

    [SerializeField]
    private SentisDualHeadPolicyValueEvaluator alphaZeroD2Evaluator;

    [Header("Final A / B / C Evaluators") ]
    [SerializeField]
    private SentisDualHeadPolicyValueEvaluator modelAPrimeEvaluator;

    [SerializeField]
    private SentisDualHeadPolicyValueEvaluator modelBPrimeEvaluator;

    [SerializeField]
    private SentisDualHeadPolicyValueEvaluator modelCPrimeEvaluator;

    [Header("Minimax")]
    [Min(1)]
    [SerializeField]
    private int minimaxDepth = 4;

    [SerializeField]
    private bool minimaxHistory = true;

    [SerializeField]
    private bool minimaxKiller = true;

    [SerializeField]
    private bool minimaxTranspositionTable = true;

    [SerializeField]
    private bool minimaxAspiration = true;

    [Header("AlphaZero")]
    [Min(1)]
    [SerializeField]
    private int alphaZeroSimulations = 100;

    [Min(1)]
    [SerializeField]
    private int alphaZeroMaxDepth = 64;

    [Min(0.01f)]
    [SerializeField]
    private float alphaZeroCpuct = 1.5f;

    [SerializeField]
    private float alphaZeroTemperature = 0.05f;

    [Header("Tournament")]
    [Min(1)]
    [SerializeField]
    private int gamesPerPair = 20;

    [Min(1)]
    [SerializeField]
    private int maxPliesPerGame = 500;

    [SerializeField]
    private int randomSeed = 20260922;

    [SerializeField]
    private bool alternateColors = true;

    [SerializeField]
    private bool alternatePairOrder = true;

    [Header("Draw Rules")]
    [Min(2)]
    [SerializeField]
    private int repetitionDrawOccurrences = 3;

    [Min(1)]
    [SerializeField]
    private int noProgressDrawPlies = 32;

    [Header("Output")]
    [SerializeField]
    private string outputDirectory = "TournamentResults";

    [SerializeField]
    private bool writePerGameCsv = true;

    [SerializeField]
    private bool writeSummaryCsv = true;

    [SerializeField]
    private bool logProgress = true;

    private Coroutine _tournamentCoroutine;

    [Serializable]
    private sealed class ParticipantRuntime
    {
        public AIPlayerDescriptor descriptor;
        public IPolicyEvaluator ppo;
        public IPolicyValueEvaluator alphaZero;
    }

    private sealed class MoveDecision
    {
        public StateMove move;
        public double milliseconds;
        public long nodes;
        public int mctsSimulations;
        public bool hasMcts;
    }

    private readonly List<AITournamentMetrics> _summaries =
        new List<AITournamentMetrics>();

    [ContextMenu("Run Full AI Tournament")]
    public void RunFullTournament()
    {
        if (_tournamentCoroutine != null)
        {
            Debug.LogWarning("[AI Tournament] Tournament is already running.", this);
            return;
        }

        _tournamentCoroutine = StartCoroutine(RunTournamentRoutine());
    }

    public void StopTournament()
    {
        if (_tournamentCoroutine == null)
            return;

        StopCoroutine(_tournamentCoroutine);
        _tournamentCoroutine = null;
        Debug.LogWarning("[AI Tournament] Tournament stopped.", this);
    }

    private IEnumerator RunTournamentRoutine()
    {
        EnsureEvaluatorReferences();

        List<AIPlayerDescriptor> participants = BuildParticipants();
        if (participants.Count < 2)
        {
            Debug.LogError(
                "[AI Tournament] Need at least two valid participants. " +
                "For PPO/AZ variants, assign their evaluator components.",
                this);
            _tournamentCoroutine = null;
            yield break;
        }

        GameState initialState = CaptureInitialState();
        if (initialState == null)
        {
            _tournamentCoroutine = null;
            yield break;
        }

        string directory = ResolveOutputDirectory();
        Directory.CreateDirectory(directory);

        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string perGamePath = Path.Combine(directory, "AITournament_Games_" + timestamp + ".csv");
        string summaryPath = Path.Combine(directory, "AITournament_Summary_" + timestamp + ".csv");
        string overallPath = Path.Combine(directory, "AITournament_Overall_" + timestamp + ".csv");

        using (StreamWriter perGameWriter = writePerGameCsv
                   ? new StreamWriter(perGamePath, false, Encoding.UTF8)
                   : null)
        using (StreamWriter summaryWriter = writeSummaryCsv
                   ? new StreamWriter(summaryPath, false, Encoding.UTF8)
                   : null)
        using (StreamWriter overallWriter = writeSummaryCsv
                   ? new StreamWriter(overallPath, false, Encoding.UTF8)
                   : null)
        {
            if (perGameWriter != null)
            {
                perGameWriter.WriteLine(
                    "Pair,Game,White,Black,Winner,DrawReason,Plies,Captures,Checks,Promotions," +
                    "WhiteThinkMs,BlackThinkMs,WhiteNodes,BlackNodes,MctsSimulations,MctsSearchMs");
            }

            for (int i = 0; i < participants.Count; i++)
            {
                for (int j = i + 1; j < participants.Count; j++)
                {
                    ParticipantRuntime a = CreateRuntime(participants[i]);
                    ParticipantRuntime b = CreateRuntime(participants[j]);
                    if (a == null || b == null)
                        continue;

                    AITournamentMetrics summary =
                        new AITournamentMetrics(participants[i].displayName, participants[j].displayName);
                    _summaries.Add(summary);

                    int totalGames = Mathf.Max(1, gamesPerPair);

                    for (int game = 0; game < totalGames; game++)
                    {
                        bool aWhite = alternateColors
                            ? ((game & 1) == 0)
                            : true;

                        if (alternatePairOrder && ((game / 2) & 1) == 1)
                            aWhite = !aWhite;

                        ParticipantRuntime white = aWhite ? a : b;
                        ParticipantRuntime black = aWhite ? b : a;

                        System.Random rng = new System.Random(
                            randomSeed + i * 100000 + j * 1000 + game);

                        GameSimulationResult result =
                            SimulateGame(initialState, white, black, rng);

                        summary.AddGame(
                            result.winner,
                            result.plies,
                            result.captures,
                            result.checks,
                            result.promotions);

                        summary.totalWhiteSearchMs += result.whiteThinkMs;
                        summary.totalBlackSearchMs += result.blackThinkMs;
                        summary.totalWhiteNodes += result.whiteNodes;
                        summary.totalBlackNodes += result.blackNodes;
                        summary.totalMctsSimulations += result.mctsSimulations;
                        summary.totalMctsSearchMs += result.mctsSearchMs;

                        if (perGameWriter != null)
                        {
                            perGameWriter.WriteLine(
                                string.Join(",",
                                    Escape(participants[i].displayName + " vs " + participants[j].displayName),
                                    game + 1,
                                    Escape(white.descriptor.displayName),
                                    Escape(black.descriptor.displayName),
                                    result.winner.HasValue ? result.winner.Value.ToString() : "DRAW",
                                    result.drawReason,
                                    result.plies,
                                    result.captures,
                                    result.checks,
                                    result.promotions,
                                    F(result.whiteThinkMs),
                                    F(result.blackThinkMs),
                                    result.whiteNodes,
                                    result.blackNodes,
                                    result.mctsSimulations,
                                    F(result.mctsSearchMs)));
                            perGameWriter.Flush();
                        }

                        if (logProgress)
                        {
                            ShafranDebug.Log(
                                "[AI Tournament] " +
                                $"{participants[i].displayName} vs {participants[j].displayName} | " +
                                $"Game {game + 1}/{totalGames} | " +
                                $"Winner={(result.winner.HasValue ? result.winner.Value.ToString() : "DRAW")} | " +
                                $"Ply={result.plies}",
                                this);
                        }

                        // Yield every game so the Unity editor/player remains responsive.
                        yield return null;
                    }
                }
            }

            if (summaryWriter != null)
            {
                summaryWriter.WriteLine(
                    "White,Black,Games,WhiteWins,BlackWins,Draws,WhiteWinRate,BlackWinRate,DrawRate," +
                    "AveragePlies,AverageCaptures,AverageChecks,AveragePromotions,TotalWhiteSearchMs," +
                    "TotalBlackSearchMs,TotalWhiteNodes,TotalBlackNodes,TotalMctsSimulations,TotalMctsSearchMs");

                for (int i = 0; i < _summaries.Count; i++)
                {
                    AITournamentMetrics m = _summaries[i];
                    summaryWriter.WriteLine(
                        string.Join(",",
                            Escape(m.playerWhite),
                            Escape(m.playerBlack),
                            m.games,
                            m.whiteWins,
                            m.blackWins,
                            m.draws,
                            F(m.WhiteWinRate),
                            F(m.BlackWinRate),
                            F(m.DrawRate),
                            F(m.AveragePlies),
                            F(m.AverageCaptures),
                            F(m.AverageChecks),
                            m.totalPromotions,
                            F(m.totalWhiteSearchMs),
                            F(m.totalBlackSearchMs),
                            m.totalWhiteNodes,
                            m.totalBlackNodes,
                            m.totalMctsSimulations,
                            F(m.totalMctsSearchMs)));
                }

                summaryWriter.Flush();
            }

            if (overallWriter != null)
            {
                overallWriter.WriteLine(
                    "Participant,Games,Wins,Losses,Draws,WinRate,LossRate,DrawRate,AveragePlies,AverageCaptures,AverageChecks");

                Dictionary<string, OverallStats> overall = BuildOverallStats();
                foreach (KeyValuePair<string, OverallStats> pair in overall)
                {
                    OverallStats s = pair.Value;
                    overallWriter.WriteLine(
                        string.Join(",",
                            Escape(pair.Key),
                            s.games,
                            s.wins,
                            s.losses,
                            s.draws,
                            F(s.Games > 0 ? (double)s.wins / s.games : 0.0),
                            F(s.Games > 0 ? (double)s.losses / s.games : 0.0),
                            F(s.Games > 0 ? (double)s.draws / s.games : 0.0),
                            F(s.games > 0 ? (double)s.totalPlies / s.games : 0.0),
                            F(s.games > 0 ? (double)s.totalCaptures / s.games : 0.0),
                            F(s.games > 0 ? (double)s.totalChecks / s.games : 0.0)));
                }
                overallWriter.Flush();
            }
        }

        _tournamentCoroutine = null;

        ShafranDebug.Log(
            "[AI Tournament] COMPLETE\n" +
            $"Games={ComputeTotalGames()} | " +
            $"Output={directory}",
            this);
    }

    private GameSimulationResult SimulateGame(
        GameState initialState,
        ParticipantRuntime white,
        ParticipantRuntime black,
        System.Random rng)
    {
        GameState state = initialState.Clone();
        MoveGenerator moveGenerator = new MoveGenerator();
        Dictionary<ulong, int> repetition = new Dictionary<ulong, int>(512);
        repetition[state.Hash] = 1;

        int plies = 0;
        int captures = 0;
        int checks = 0;
        int promotions = 0;
        int noProgress = 0;
        EPlayer? winner = null;
        string drawReason = "";

        double whiteThinkMs = 0.0;
        double blackThinkMs = 0.0;
        long whiteNodes = 0;
        long blackNodes = 0;
        int mctsSimulations = 0;
        double mctsSearchMs = 0.0;

        while (plies < Mathf.Max(1, maxPliesPerGame))
        {
            List<StateMove> legalMoves =
                moveGenerator.GenerateLegalMoves(state, state.SideToMove);

            if (legalMoves == null || legalMoves.Count == 0)
            {
                bool inCheck = moveGenerator.IsInCheck(state, state.SideToMove);
                if (inCheck)
                    winner = HexChessRules.GetOpponent(state.SideToMove);
                else
                    drawReason = "NoLegalMoves";
                break;
            }

            ParticipantRuntime current =
                state.SideToMove == EPlayer.WHITE ? white : black;

            MoveDecision decision = ChooseMove(current, state, legalMoves, repetition, noProgress);
            StateMove selectedMove = decision.move;

            if (!ContainsAction(legalMoves, selectedMove))
                selectedMove = legalMoves[rng.Next(legalMoves.Count)];

            if (state.SideToMove == EPlayer.WHITE)
            {
                whiteThinkMs += decision.milliseconds;
                whiteNodes += decision.nodes;
            }
            else
            {
                blackThinkMs += decision.milliseconds;
                blackNodes += decision.nodes;
            }

            mctsSimulations += decision.mctsSimulations;
            mctsSearchMs += decision.hasMcts ? decision.milliseconds : 0.0;

            if (selectedMove.IsCapture || selectedMove.IsEnPassant)
                captures++;
            if (selectedMove.IsPromotion)
                promotions++;

            moveGenerator.MakeMove(state, selectedMove);
            plies++;

            // Keep tournament terminal rules identical to PPO, Minimax and
            // AlphaZero: only configured insufficient-material cases draw;
            // material advantage alone is never an automatic win.
            if (HexChessRules.TryGetMaterialTerminalResult(
                    state,
                    out EPlayer? materialWinner,
                    out bool materialDraw))
            {
                if (materialDraw)
                    drawReason = "KingVsKing";
                else if (materialWinner.HasValue)
                    winner = materialWinner.Value;

                break;
            }

            bool progress =
                selectedMove.IsCapture ||
                selectedMove.IsEnPassant ||
                selectedMove.IsPromotion ||
                selectedMove.MovingPiece.Type == StatePieceType.PAWN;

            if (progress)
                noProgress = 0;
            else
                noProgress++;

            List<StateMove> opponentMoves =
                moveGenerator.GenerateLegalMoves(state, state.SideToMove);
            if (opponentMoves == null || opponentMoves.Count == 0)
            {
                if (moveGenerator.IsInCheck(state, state.SideToMove))
                    winner = HexChessRules.GetOpponent(state.SideToMove);
                else
                    drawReason = "NoLegalMoves";
                break;
            }

            if (moveGenerator.IsInCheck(state, state.SideToMove))
                checks++;

            if (repetition.TryGetValue(state.Hash, out int count))
                repetition[state.Hash] = count + 1;
            else
                repetition[state.Hash] = 1;

            if (repetition[state.Hash] >= Mathf.Max(2, repetitionDrawOccurrences))
            {
                drawReason = "Repetition";
                break;
            }

            if (noProgress >= Mathf.Max(1, noProgressDrawPlies))
            {
                drawReason = "NoProgress";
                break;
            }
        }

        if (!winner.HasValue && string.IsNullOrEmpty(drawReason) && plies >= maxPliesPerGame)
            drawReason = "MaxPlies";

        return new GameSimulationResult(
            winner,
            drawReason,
            plies,
            captures,
            checks,
            promotions,
            whiteThinkMs,
            blackThinkMs,
            whiteNodes,
            blackNodes,
            mctsSimulations,
            mctsSearchMs);
    }

    private MoveDecision ChooseMove(
        ParticipantRuntime player,
        GameState state,
        IReadOnlyList<StateMove> legalMoves,
        IReadOnlyDictionary<ulong, int> repetition,
        int noProgress)
    {
        if (player == null || player.descriptor == null)
            return new MoveDecision { move = legalMoves[0] };

        if (player.descriptor.kind == AIPlayerKind.MINIMAX_ALPHA_BETA)
        {
            MinimaxAI ai = new MinimaxAI(
                state.SideToMove,
                Mathf.Max(1, player.descriptor.minimaxDepth),
                player.descriptor.minimaxHistory,
                player.descriptor.minimaxKiller,
                player.descriptor.minimaxTranspositionTable,
                player.descriptor.minimaxAspiration);

            float start = Time.realtimeSinceStartup;
            StateMove move = ai.GetBestStateMove(state);
            double elapsed = (Time.realtimeSinceStartup - start) * 1000.0;

            return new MoveDecision
            {
                move = move,
                milliseconds = elapsed,
                nodes = ai.Statistics.Nodes
            };
        }

        if (player.descriptor.IsPpo)
        {
            if (player.ppo == null)
                return new MoveDecision { move = legalMoves[0] };

            float start = Time.realtimeSinceStartup;
            float[] policy = player.ppo.EvaluatePolicy(
                state,
                state.SideToMove,
                legalMoves);

            StateMove move = AlphaZeroSearch.ChooseMoveFromPolicy(
                state,
                legalMoves,
                policy,
                alphaZeroTemperature);

            return new MoveDecision
            {
                move = move,
                milliseconds = (Time.realtimeSinceStartup - start) * 1000.0
            };
        }

        if (player.descriptor.IsAlphaZero)
        {
            if (player.alphaZero == null)
                return new MoveDecision { move = legalMoves[0] };

            AlphaZeroConfig config = new AlphaZeroConfig
            {
                simulations = Mathf.Max(1, player.descriptor.alphaZeroSimulations),
                maxDepth = Mathf.Max(1, player.descriptor.alphaZeroMaxDepth),
                cpuct = Mathf.Max(0.01f, player.descriptor.alphaZeroCpuct),
                policyTemperature = 1f,
                rootDirichletEpsilon = 0f,
                rootDirichletAlpha = 0.30f,
                enableRepetitionAwareness = true,
                repetitionCutoffOccurrences = Mathf.Max(2, repetitionDrawOccurrences),
                enableNoProgressAwareness = true,
                noProgressPlyThreshold = Mathf.Max(1, noProgressDrawPlies),
                inheritGameNoProgressIntoSearch = false,
                enableDiagnostics = false
            };

            AlphaZeroSearch search = new AlphaZeroSearch(player.alphaZero, config);
            MCTSSearchResult result = search.Search(state, repetition, noProgress);

            return new MoveDecision
            {
                move = AlphaZeroSearch.ChooseMove(
                    result,
                    legalMoves,
                    alphaZeroTemperature),
                milliseconds = result.SearchTimeMilliseconds,
                nodes = 0,
                mctsSimulations = result.CompletedSimulations,
                hasMcts = true
            };
        }

        return new MoveDecision { move = legalMoves[0] };
    }

    private GameState CaptureInitialState()
    {
        if (ChessBoard.Current == null)
        {
            Debug.LogError("[AI Tournament] ChessBoard.Current is null.", this);
            return null;
        }

        MonoBehaviour liveController = BaseGameController.Current as MonoBehaviour;
        bool restore = liveController != null && liveController.enabled;

        try
        {
            if (liveController != null)
                liveController.enabled = false;

            ChessBoard.Current.ResetBoard();
            if (BaseGameController.Current != null)
                BaseGameController.Current.ResetGameState();

            GameState initial = GameState.FromUnityBoard();
            if (initial == null)
                return null;

            MoveGenerator generator = new MoveGenerator();
            List<StateMove> legal = generator.GenerateLegalMoves(initial, initial.SideToMove);
            if (legal == null || legal.Count == 0)
            {
                Debug.LogError("[AI Tournament] Initial position has no legal moves.", this);
                return null;
            }

            return initial;
        }
        finally
        {
            if (liveController != null)
                liveController.enabled = restore;
        }
    }

    private void EnsureEvaluatorReferences()
    {
        if (ppoBaseEvaluator == null)
            ppoBaseEvaluator = FindAnyObjectByType<SentisPpoPolicyEvaluator>();

        if (alphaZeroBaseEvaluator == null)
            alphaZeroBaseEvaluator = FindAnyObjectByType<SentisDualHeadPolicyValueEvaluator>();
    }

    private List<AIPlayerDescriptor> BuildParticipants()
    {
        if (finalThreeOnly)
        {
            List<AIPlayerDescriptor> finalParticipants =
                new List<AIPlayerDescriptor>(3);

            if (enableModelAPrime && modelAPrimeEvaluator != null)
            {
                finalParticipants.Add(new AIPlayerDescriptor
                {
                    displayName = "MODEL_A_PRIME",
                    kind = AIPlayerKind.MODEL_A_PRIME,
                    alphaZeroPolicyValueEvaluator = modelAPrimeEvaluator,
                    alphaZeroSimulations = alphaZeroSimulations,
                    alphaZeroMaxDepth = alphaZeroMaxDepth,
                    alphaZeroCpuct = alphaZeroCpuct
                });
            }

            if (enableModelBPrime && modelBPrimeEvaluator != null)
            {
                finalParticipants.Add(new AIPlayerDescriptor
                {
                    displayName = "MODEL_B_PRIME",
                    kind = AIPlayerKind.MODEL_B_PRIME,
                    alphaZeroPolicyValueEvaluator = modelBPrimeEvaluator,
                    alphaZeroSimulations = alphaZeroSimulations,
                    alphaZeroMaxDepth = alphaZeroMaxDepth,
                    alphaZeroCpuct = alphaZeroCpuct
                });
            }

            if (enableModelCPrime && modelCPrimeEvaluator != null)
            {
                finalParticipants.Add(new AIPlayerDescriptor
                {
                    displayName = "MODEL_C_PRIME",
                    kind = AIPlayerKind.MODEL_C_PRIME,
                    alphaZeroPolicyValueEvaluator = modelCPrimeEvaluator,
                    alphaZeroSimulations = alphaZeroSimulations,
                    alphaZeroMaxDepth = alphaZeroMaxDepth,
                    alphaZeroCpuct = alphaZeroCpuct
                });
            }

            return finalParticipants;
        }

        List<AIPlayerDescriptor> result = new List<AIPlayerDescriptor>(10);

        if (enableMinimax)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "Minimax_AlphaBeta",
                kind = AIPlayerKind.MINIMAX_ALPHA_BETA,
                minimaxDepth = minimaxDepth,
                minimaxHistory = minimaxHistory,
                minimaxKiller = minimaxKiller,
                minimaxTranspositionTable = minimaxTranspositionTable,
                minimaxAspiration = minimaxAspiration
            });

        if (enablePpoBase && ppoBaseEvaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "PPO_Base",
                kind = AIPlayerKind.PPO_BASE,
                ppoPolicyEvaluator = ppoBaseEvaluator
            });

        if (enablePpoD1 && ppoD1Evaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "PPO_Minimax_D1",
                kind = AIPlayerKind.PPO_MINIMAX_D1,
                ppoPolicyEvaluator = ppoD1Evaluator
            });

        if (enablePpoD2 && ppoD2Evaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "PPO_Minimax_D2",
                kind = AIPlayerKind.PPO_MINIMAX_D2,
                ppoPolicyEvaluator = ppoD2Evaluator
            });

        if (enableAlphaZeroBase && alphaZeroBaseEvaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "AlphaZero_Base",
                kind = AIPlayerKind.ALPHAZERO_BASE,
                alphaZeroPolicyValueEvaluator = alphaZeroBaseEvaluator,
                alphaZeroSimulations = alphaZeroSimulations,
                alphaZeroMaxDepth = alphaZeroMaxDepth,
                alphaZeroCpuct = alphaZeroCpuct
            });

        if (enableAlphaZeroD1 && alphaZeroD1Evaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "AlphaZero_From_PPO_D1",
                kind = AIPlayerKind.ALPHAZERO_FROM_PPO_D1,
                alphaZeroPolicyValueEvaluator = alphaZeroD1Evaluator,
                alphaZeroSimulations = alphaZeroSimulations,
                alphaZeroMaxDepth = alphaZeroMaxDepth,
                alphaZeroCpuct = alphaZeroCpuct
            });

        if (enableAlphaZeroD2 && alphaZeroD2Evaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "AlphaZero_From_PPO_D2",
                kind = AIPlayerKind.ALPHAZERO_FROM_PPO_D2,
                alphaZeroPolicyValueEvaluator = alphaZeroD2Evaluator,
                alphaZeroSimulations = alphaZeroSimulations,
                alphaZeroMaxDepth = alphaZeroMaxDepth,
                alphaZeroCpuct = alphaZeroCpuct
            });

        if (enableModelAPrime && modelAPrimeEvaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "MODEL_A_PRIME",
                kind = AIPlayerKind.MODEL_A_PRIME,
                alphaZeroPolicyValueEvaluator = modelAPrimeEvaluator,
                alphaZeroSimulations = alphaZeroSimulations,
                alphaZeroMaxDepth = alphaZeroMaxDepth,
                alphaZeroCpuct = alphaZeroCpuct
            });

        if (enableModelBPrime && modelBPrimeEvaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "MODEL_B_PRIME",
                kind = AIPlayerKind.MODEL_B_PRIME,
                alphaZeroPolicyValueEvaluator = modelBPrimeEvaluator,
                alphaZeroSimulations = alphaZeroSimulations,
                alphaZeroMaxDepth = alphaZeroMaxDepth,
                alphaZeroCpuct = alphaZeroCpuct
            });

        if (enableModelCPrime && modelCPrimeEvaluator != null)
            result.Add(new AIPlayerDescriptor
            {
                displayName = "MODEL_C_PRIME",
                kind = AIPlayerKind.MODEL_C_PRIME,
                alphaZeroPolicyValueEvaluator = modelCPrimeEvaluator,
                alphaZeroSimulations = alphaZeroSimulations,
                alphaZeroMaxDepth = alphaZeroMaxDepth,
                alphaZeroCpuct = alphaZeroCpuct
            });

        return result;
    }

    private ParticipantRuntime CreateRuntime(AIPlayerDescriptor descriptor)
    {
        if (descriptor == null)
            return null;

        return new ParticipantRuntime
        {
            descriptor = descriptor,
            ppo = descriptor.ppoPolicyEvaluator as IPolicyEvaluator,
            alphaZero = descriptor.alphaZeroPolicyValueEvaluator as IPolicyValueEvaluator
        };
    }

    private static bool ContainsAction(
        IReadOnlyList<StateMove> moves,
        StateMove target)
    {
        int targetAction = AlphaZeroActionEncoder.Encode(target);
        if (targetAction < 0)
            return false;

        for (int i = 0; i < moves.Count; i++)
        {
            if (AlphaZeroActionEncoder.Encode(moves[i]) == targetAction)
                return true;
        }

        return false;
    }

    private string ResolveOutputDirectory()
    {
        if (string.IsNullOrWhiteSpace(outputDirectory))
            return Application.persistentDataPath;

        if (Path.IsPathRooted(outputDirectory))
            return outputDirectory;

        return Path.Combine(Application.persistentDataPath, outputDirectory);
    }

    private int ComputeTotalGames()
    {
        int count = 0;
        for (int i = 0; i < _summaries.Count; i++)
            count += _summaries[i].games;
        return count;
    }

    private Dictionary<string, OverallStats> BuildOverallStats()
    {
        Dictionary<string, OverallStats> result =
            new Dictionary<string, OverallStats>(StringComparer.Ordinal);

        for (int i = 0; i < _summaries.Count; i++)
        {
            AITournamentMetrics m = _summaries[i];

            OverallStats white = GetOrCreateOverall(result, m.playerWhite);
            white.games += m.games;
            white.wins += m.whiteWins;
            white.losses += m.blackWins;
            white.draws += m.draws;
            white.totalPlies += m.totalPlies;
            white.totalCaptures += m.totalCaptures;
            white.totalChecks += m.totalChecks;

            OverallStats black = GetOrCreateOverall(result, m.playerBlack);
            black.games += m.games;
            black.wins += m.blackWins;
            black.losses += m.whiteWins;
            black.draws += m.draws;
            black.totalPlies += m.totalPlies;
            black.totalCaptures += m.totalCaptures;
            black.totalChecks += m.totalChecks;
        }

        return result;
    }

    private static OverallStats GetOrCreateOverall(
        Dictionary<string, OverallStats> dictionary,
        string name)
    {
        if (!dictionary.TryGetValue(name, out OverallStats stats))
        {
            stats = new OverallStats();
            dictionary[name] = stats;
        }
        return stats;
    }

    private static string Escape(string value)
    {
        if (value == null)
            return "";

        if (value.Contains(",") || value.Contains("\"") || value.Contains("\n"))
            return "\"" + value.Replace("\"", "\"\"") + "\"";

        return value;
    }

    private static string F(double value)
    {
        return value.ToString("0.######", CultureInfo.InvariantCulture);
    }

    private sealed class OverallStats
    {
        public int games;
        public int wins;
        public int losses;
        public int draws;
        public long totalPlies;
        public long totalCaptures;
        public long totalChecks;

        public int Games => games;
    }

    private sealed class GameSimulationResult
    {
        public readonly EPlayer? winner;
        public readonly string drawReason;
        public readonly int plies;
        public readonly int captures;
        public readonly int checks;
        public readonly int promotions;
        public readonly double whiteThinkMs;
        public readonly double blackThinkMs;
        public readonly long whiteNodes;
        public readonly long blackNodes;
        public readonly int mctsSimulations;
        public readonly double mctsSearchMs;

        public GameSimulationResult(
            EPlayer? winner,
            string drawReason,
            int plies,
            int captures,
            int checks,
            int promotions,
            double whiteThinkMs,
            double blackThinkMs,
            long whiteNodes,
            long blackNodes,
            int mctsSimulations,
            double mctsSearchMs)
        {
            this.winner = winner;
            this.drawReason = drawReason ?? "";
            this.plies = plies;
            this.captures = captures;
            this.checks = checks;
            this.promotions = promotions;
            this.whiteThinkMs = whiteThinkMs;
            this.blackThinkMs = blackThinkMs;
            this.whiteNodes = whiteNodes;
            this.blackNodes = blackNodes;
            this.mctsSimulations = mctsSimulations;
            this.mctsSearchMs = mctsSearchMs;
        }
    }
}
