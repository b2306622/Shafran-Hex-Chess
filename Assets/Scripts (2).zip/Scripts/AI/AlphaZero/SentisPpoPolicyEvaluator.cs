using System;
using System.Collections.Generic;
using Unity.InferenceEngine;
using UnityEngine;

/// <summary>
/// Adapter for an ML-Agents PPO ONNX model used only as a policy source in
/// offline evaluation/distillation/tournament runs.
///
/// Expected input: [1, 986].
/// Expected policy output: a tensor containing 4900 action scores/probabilities.
/// The output name/index is configurable because ML-Agents ONNX export names
/// vary by package/version.
/// </summary>
public sealed class SentisPpoPolicyEvaluator : MonoBehaviour, IPolicyEvaluator
{
    [Header("Model")]
    [SerializeField]
    private ModelAsset modelAsset;

    [SerializeField]
    private string resourcesModelPath = "AI/ChessPPO";

    [SerializeField]
    private string inputName = "obs_0";

    [Header("Policy Output")]
    [Tooltip("Leave empty to use policyOutputIndex.")]
    [SerializeField]
    private string policyOutputName = "";

    [SerializeField]
    private int policyOutputIndex = 0;

    [Tooltip("True when the PPO output contains logits. False when it already contains non-negative probabilities.")]
    [SerializeField]
    private bool policyIsLogits = true;

    [Header("Backend")]
    [SerializeField]
    private bool useGpu = false;

    [Header("Diagnostics")]
    [SerializeField]
    private bool logFirstSuccessfulInference = true;

    [SerializeField]
    private bool logInferenceFailures = true;

    private Worker _worker;
    private Model _runtimeModel;
    private Tensor<float> _inputTensor;
    private float[] _inputBuffer;
    private bool _initialized;
    private bool _loggedFirstInference;

    public bool IsReady =>
        _initialized &&
        _worker != null &&
        _inputTensor != null;

    private void Awake()
    {
        TryInitialize();
    }

    private void OnEnable()
    {
        if (!IsReady)
            TryInitialize();
    }

    private void OnDisable()
    {
        DisposeRuntime();
    }

    private void OnDestroy()
    {
        DisposeRuntime();
    }

    [ContextMenu("Reinitialize PPO Policy Evaluator")]
    public bool TryInitialize()
    {
        DisposeRuntime();

        if (modelAsset == null && !string.IsNullOrWhiteSpace(resourcesModelPath))
            modelAsset = Resources.Load<ModelAsset>(resourcesModelPath);

        if (modelAsset == null)
        {
            Debug.LogWarning(
                "[PPO Policy] No ModelAsset assigned and Resources model was not found at: " +
                resourcesModelPath,
                this);
            return false;
        }

        try
        {
            _runtimeModel = ModelLoader.Load(modelAsset);

            BackendType backend =
                useGpu && SystemInfo.supportsComputeShaders
                    ? BackendType.GPUCompute
                    : BackendType.CPU;

            _worker = new Worker(_runtimeModel, backend);

            _inputBuffer = new float[AlphaZeroStateEncoder.ObservationSize];
            _inputTensor = new Tensor<float>(
                new TensorShape(1, AlphaZeroStateEncoder.ObservationSize),
                _inputBuffer);

            _initialized = true;
            _loggedFirstInference = false;

            ShafranDebug.Log(
                "[PPO Policy] Initialized | " +
                $"Backend={backend} | Input={inputName}[{AlphaZeroStateEncoder.ObservationSize}] | " +
                $"Output={(string.IsNullOrWhiteSpace(policyOutputName) ? policyOutputIndex.ToString() : policyOutputName)}",
                this);

            return true;
        }
        catch (Exception exception)
        {
            Debug.LogError("[PPO Policy] Initialization failed.\n" + exception, this);
            DisposeRuntime();
            return false;
        }
    }

    public float[] EvaluatePolicy(
        GameState state,
        EPlayer perspective,
        IReadOnlyList<StateMove> legalMoves)
    {
        float[] fallback = BuildUniformPolicy(legalMoves);

        if (!IsReady || state == null || legalMoves == null || legalMoves.Count == 0)
            return fallback;

        try
        {
            AlphaZeroStateEncoder.EncodeTo(state, perspective, _inputBuffer);
            _inputTensor.Upload(_inputBuffer);
            _worker.SetInput(inputName, _inputTensor);
            _worker.Schedule();

            Tensor tensor = GetPolicyOutput();
            Tensor<float> floatTensor = tensor as Tensor<float>;

            if (floatTensor == null)
                throw new InvalidOperationException("PPO policy output is not Tensor<float>.");

            float[] raw = floatTensor.DownloadToArray();

            if (raw == null || raw.Length != AlphaZeroActionEncoder.ActionCount)
            {
                throw new InvalidOperationException(
                    $"PPO action output size mismatch. Expected={AlphaZeroActionEncoder.ActionCount}, Actual={raw?.Length ?? 0}.");
            }

            float[] legalPolicy = BuildLegalPolicy(raw, legalMoves);

            if (logFirstSuccessfulInference && !_loggedFirstInference)
            {
                _loggedFirstInference = true;
                ShafranDebug.Log(
                    "[PPO Policy] First inference OK | " +
                    $"Output={raw.Length} | LegalMoves={legalMoves.Count}",
                    this);
            }

            return legalPolicy;
        }
        catch (Exception exception)
        {
            if (logInferenceFailures)
            {
                Debug.LogError(
                    "[PPO Policy] Inference failed. Check input/output names and PPO ONNX action size.\n" +
                    exception,
                    this);
            }

            return fallback;
        }
    }

    private Tensor GetPolicyOutput()
    {
        if (!string.IsNullOrWhiteSpace(policyOutputName))
        {
            try
            {
                Tensor named = _worker.PeekOutput(policyOutputName);
                if (named != null)
                    return named;
            }
            catch
            {
                // Fall through to index.
            }
        }

        return _worker.PeekOutput(policyOutputIndex);
    }

    private float[] BuildLegalPolicy(
        float[] raw,
        IReadOnlyList<StateMove> legalMoves)
    {
        float[] policy =
            new float[AlphaZeroActionEncoder.ActionCount];

        if (raw == null || legalMoves == null || legalMoves.Count == 0)
            return policy;

        float maxLogit = float.NegativeInfinity;

        for (int i = 0; i < legalMoves.Count; i++)
        {
            int action = AlphaZeroActionEncoder.Encode(legalMoves[i]);
            if (action >= 0 && action < raw.Length)
                maxLogit = Mathf.Max(maxLogit, raw[action]);
        }

        float sum = 0f;

        for (int i = 0; i < legalMoves.Count; i++)
        {
            int action = AlphaZeroActionEncoder.Encode(legalMoves[i]);
            if (action < 0 || action >= raw.Length)
                continue;

            float probability;

            if (policyIsLogits)
            {
                if (float.IsNegativeInfinity(maxLogit))
                    continue;

                probability = Mathf.Exp(
                    Mathf.Clamp(raw[action] - maxLogit, -30f, 30f));
            }
            else
            {
                probability = Mathf.Max(0f, raw[action]);
            }

            if (float.IsNaN(probability) || float.IsInfinity(probability))
                probability = 0f;

            policy[action] = probability;
            sum += probability;
        }

        if (sum <= 1e-8f || float.IsNaN(sum) || float.IsInfinity(sum))
            return BuildUniformPolicy(legalMoves);

        for (int i = 0; i < policy.Length; i++)
            policy[i] /= sum;

        return policy;
    }

    private static float[] BuildUniformPolicy(IReadOnlyList<StateMove> legalMoves)
    {
        float[] policy = new float[AlphaZeroActionEncoder.ActionCount];
        if (legalMoves == null || legalMoves.Count == 0)
            return policy;

        int valid = 0;
        for (int i = 0; i < legalMoves.Count; i++)
        {
            int action = AlphaZeroActionEncoder.Encode(legalMoves[i]);
            if (action >= 0 && action < policy.Length)
                valid++;
        }

        if (valid == 0)
            return policy;

        float uniform = 1f / valid;
        for (int i = 0; i < legalMoves.Count; i++)
        {
            int action = AlphaZeroActionEncoder.Encode(legalMoves[i]);
            if (action >= 0 && action < policy.Length)
                policy[action] = uniform;
        }

        return policy;
    }

    private void DisposeRuntime()
    {
        if (_worker != null)
        {
            try { _worker.Dispose(); }
            catch (Exception exception)
            {
                Debug.LogWarning("[PPO Policy] Worker.Dispose failed.\n" + exception, this);
            }
            _worker = null;
        }

        if (_inputTensor != null)
        {
            try { _inputTensor.Dispose(); }
            catch (Exception exception)
            {
                Debug.LogWarning("[PPO Policy] Input tensor Dispose failed.\n" + exception, this);
            }
            _inputTensor = null;
        }

        _runtimeModel = null;
        _inputBuffer = null;
        _initialized = false;
    }
}
