using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Branch-specific AlphaZero bootstrap evaluator for Model A/B/C.
/// It uses a branch's PPO policy as the MCTS prior and the shared Shafran
/// heuristic evaluator as the initial value estimate. The two legal-action
/// policies are blended so the MCTS does not inherit every early PPO mistake.
/// </summary>
public sealed class ShafranPPOBootstrapPolicyValueEvaluator : MonoBehaviour, IPolicyValueEvaluator
{
    [Header("Branch Identity")]
    [SerializeField]
    private string modelId = "MODEL_A";

    [Header("Evaluators")]
    [SerializeField]
    private SentisPpoPolicyEvaluator ppoPolicyEvaluator;

    [SerializeField]
    private HeuristicPolicyValueEvaluator heuristicValueEvaluator;

    [Header("Policy Blend")]
    [Range(0f, 1f)]
    [SerializeField]
    private float ppoPolicyWeight = 0.80f;

    [Range(0f, 1f)]
    [SerializeField]
    private float heuristicPolicyWeight = 0.20f;

    public string ModelId => modelId;

    public PolicyValueOutput Evaluate(
        GameState state,
        EPlayer perspective,
        IReadOnlyList<StateMove> legalMoves)
    {
        int actionCount = AlphaZeroActionEncoder.ActionCount;
        float[] resultPolicy = new float[actionCount];

        if (state == null ||
            legalMoves == null ||
            legalMoves.Count == 0)
        {
            return new PolicyValueOutput(resultPolicy, 0f);
        }

        float ppoWeight = Mathf.Max(0f, ppoPolicyWeight);
        float heuristicWeight = Mathf.Max(0f, heuristicPolicyWeight);
        float totalWeight = ppoWeight + heuristicWeight;

        if (totalWeight <= 1e-6f)
        {
            ppoWeight = 1f;
            heuristicWeight = 0f;
            totalWeight = 1f;
        }

        float[] ppoPolicy = null;
        float[] heuristicPolicy = null;
        float heuristicValue = 0f;

        if (ppoPolicyEvaluator != null)
        {
            ppoPolicy =
                ppoPolicyEvaluator.EvaluatePolicy(
                    state,
                    perspective,
                    legalMoves);
        }

        if (heuristicValueEvaluator != null)
        {
            PolicyValueOutput heuristicOutput =
                heuristicValueEvaluator.Evaluate(
                    state,
                    perspective,
                    legalMoves);

            heuristicPolicy = heuristicOutput.policy;
            heuristicValue = heuristicOutput.value;
        }

        for (int i = 0; i < legalMoves.Count; i++)
        {
            int action =
                AlphaZeroActionEncoder.Encode(
                    legalMoves[i]);

            if (action < 0 || action >= actionCount)
                continue;

            float ppo =
                ppoPolicy != null && action < ppoPolicy.Length
                    ? Mathf.Max(0f, ppoPolicy[action])
                    : 0f;

            float heuristic =
                heuristicPolicy != null && action < heuristicPolicy.Length
                    ? Mathf.Max(0f, heuristicPolicy[action])
                    : 0f;

            resultPolicy[action] =
                (ppo * ppoWeight +
                 heuristic * heuristicWeight) /
                totalWeight;
        }

        NormalizeLegalPolicy(resultPolicy, legalMoves);

        return new PolicyValueOutput(
            resultPolicy,
            Mathf.Clamp(heuristicValue, -1f, 1f));
    }

    private static void NormalizeLegalPolicy(
        float[] policy,
        IReadOnlyList<StateMove> legalMoves)
    {
        float sum = 0f;

        for (int i = 0; i < legalMoves.Count; i++)
        {
            int action =
                AlphaZeroActionEncoder.Encode(
                    legalMoves[i]);

            if (action < 0 || action >= policy.Length)
                continue;

            sum += Mathf.Max(0f, policy[action]);
        }

        if (sum <= 1e-8f)
        {
            float uniform =
                1f / Mathf.Max(1, legalMoves.Count);

            for (int i = 0; i < legalMoves.Count; i++)
            {
                int action =
                    AlphaZeroActionEncoder.Encode(
                        legalMoves[i]);

                if (action >= 0 && action < policy.Length)
                    policy[action] = uniform;
            }

            return;
        }

        for (int i = 0; i < legalMoves.Count; i++)
        {
            int action =
                AlphaZeroActionEncoder.Encode(
                    legalMoves[i]);

            if (action >= 0 && action < policy.Length)
                policy[action] /= sum;
        }
    }
}
