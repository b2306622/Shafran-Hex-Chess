using UnityEngine;

/// <summary>
/// Verbose Shafran diagnostics are disabled for training builds.
/// Keep this class for source compatibility with existing calls.
/// Only final WIN/LOSS/DRAW messages from BaseGameController are intended
/// to be shown during training, while warnings/errors remain available.
/// </summary>
public static class ShafranDebug
{
    public static bool Enabled = false;

    public static void Log(object message)
    {
        // Intentionally disabled.
    }

    public static void Log(object message, Object context)
    {
        // Intentionally disabled.
    }
}
