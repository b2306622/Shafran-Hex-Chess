using UnityEngine;

public partial class ChessAgent
{
    private void ApplyInvalidMoveReward()
    {
        AddShapingReward(invalidMoveReward);
    }

    private void ApplyLegalMoveReward()
    {
        if (!Mathf.Approximately(legalMoveReward, 0f))
            AddShapingReward(legalMoveReward);
    }

    private void ApplyCaptureReward(StatePiece capturedPiece)
    {
        if (!capturedPiece.IsValid)
            return;

        float normalizedValue = Mathf.Clamp01(
            capturedPiece.Value / 1000f
        );

        AddShapingReward(
            normalizedValue * captureRewardScale
        );
    }

    // Terminal rewards are additive so previous shaping rewards are preserved.
    private void AddTrackedTerminalReward(float reward)
    {
        AddReward(reward);
        _episodeRewardAccumulator += reward;
    }

    private void ApplyWinReward()
    {
        AddTrackedTerminalReward(
            CalculateWinReward()
        );
    }

    private void ApplyLossReward()
    {
        AddTrackedTerminalReward(lossReward);
    }

    private void ApplyDrawReward()
    {
        EDrawReason reason =
            BaseGameController.Current != null &&
            BaseGameController.Current.DrawReason.HasValue
                ? BaseGameController.Current.DrawReason.Value
                : EDrawReason.Normal;

        // V10: a normal draw is neutral. This prevents PPO from learning
        // that "avoiding a loss" is itself a positive objective.
        // Only the artificial training horizon receives a small penalty.
        float reward =
            reason == EDrawReason.MaxPlies
                ? maxPlyDrawReward
                : normalDrawReward;

        AddTrackedTerminalReward(reward);
    }
}
