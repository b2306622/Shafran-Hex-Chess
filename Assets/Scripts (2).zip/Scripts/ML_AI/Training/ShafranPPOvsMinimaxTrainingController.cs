using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Explicit training switch for thesis Model B:
/// one active PPO ChessAgent plays one external Alpha-Beta Minimax opponent.
/// 
/// Put this component on any active GameObject in the training scene together
/// with an AIGameController. It disables the ChessAgent on the Minimax side,
/// configures the external controller, and leaves exactly one PPO agent active.
/// </summary>
public sealed class ShafranPPOvsMinimaxTrainingController : MonoBehaviour
{
    [Header("Experiment Identity")]
    [SerializeField]
    private string experimentId = "MODEL_B_PPO_VS_MINIMAX";

    [Header("PPO Side")]
    [SerializeField]
    private EPlayer ppoPlayerSide = EPlayer.WHITE;

    [Header("Minimax Opponent")]
    [SerializeField]
    private EPlayer minimaxPlayerSide = EPlayer.BLACK;

    [Min(1)]
    [SerializeField]
    private int minimaxDepth = 2;

    [SerializeField]
    private bool disableMinimaxSideChessAgent = true;

    [SerializeField]
    private bool validateOnStart = true;

    private readonly List<ChessAgent> _disabledAgents =
        new List<ChessAgent>();

    private void Awake()
    {
        Configure();
    }

    private void Configure()
    {
        if (ppoPlayerSide == minimaxPlayerSide)
        {
            Debug.LogError(
                "[" + experimentId + "] PPO side and Minimax side must be different.",
                this);
            return;
        }

        AIGameController controller =
            FindAnyObjectByType<AIGameController>();

        if (controller == null)
        {
            Debug.LogError(
                "[" + experimentId + "] AIGameController not found. " +
                "Model B requires an external Alpha-Beta opponent.",
                this);
            return;
        }

        controller.ConfigureTrainingOpponent(
            minimaxPlayerSide,
            Mathf.Max(1, minimaxDepth));

        ChessAgent[] agents =
            FindObjectsByType<ChessAgent>();

        int activePpoAgents = 0;
        int disabledOpponentAgents = 0;

        if (agents != null)
        {
            for (int i = 0; i < agents.Length; i++)
            {
                ChessAgent agent = agents[i];
                if (agent == null)
                    continue;

                if (agent.AgentPlayer == ppoPlayerSide)
                {
                    activePpoAgents++;
                    continue;
                }

                if (agent.AgentPlayer == minimaxPlayerSide &&
                    disableMinimaxSideChessAgent &&
                    agent.isActiveAndEnabled)
                {
                    agent.enabled = false;
                    _disabledAgents.Add(agent);
                    disabledOpponentAgents++;
                }
            }
        }

        ShafranDebug.Log(
            "[" + experimentId + "] Configured | " +
            "PPO=" + ppoPlayerSide + " | " +
            "Minimax=" + minimaxPlayerSide + " | " +
            "Depth=" + Mathf.Max(1, minimaxDepth) + " | " +
            "ActivePPOAgents=" + activePpoAgents + " | " +
            "DisabledMinimaxAgents=" + disabledOpponentAgents,
            this);

        if (validateOnStart)
        {
            if (activePpoAgents != 1)
            {
                Debug.LogError(
                    "[" + experimentId + "] Expected exactly ONE active PPO ChessAgent " +
                    "for Model B, but found " + activePpoAgents + ".",
                    this);
            }

            if (disabledOpponentAgents == 0 && disableMinimaxSideChessAgent)
            {
                Debug.LogError(
                    "[" + experimentId + "] No Minimax-side ChessAgent was disabled. " +
                    "Check AgentPlayer assignments.",
                    this);
            }
        }
    }

    private void OnDestroy()
    {
        for (int i = 0; i < _disabledAgents.Count; i++)
        {
            ChessAgent agent = _disabledAgents[i];
            if (agent != null)
                agent.enabled = true;
        }

        _disabledAgents.Clear();
    }
}
